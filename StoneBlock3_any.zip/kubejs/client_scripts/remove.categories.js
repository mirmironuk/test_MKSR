onEvent("rei.remove.categories", (event) => {
  event.remove("minecraft:plugins/tag");
});
